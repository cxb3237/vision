"""NetworkManager hotspot deployment helpers."""

